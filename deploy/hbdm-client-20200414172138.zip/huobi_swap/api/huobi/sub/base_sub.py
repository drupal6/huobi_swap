

class BaseSub:

    def __init__(self, **kwargs):
        pass

    def ch(self):
        return

    def symbol(self):
        return

    def sub_data(self):
        return

    async def call_back(self, ch, data):
        return
